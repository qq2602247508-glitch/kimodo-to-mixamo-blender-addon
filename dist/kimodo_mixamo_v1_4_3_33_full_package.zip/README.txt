Kimodo Mixamo Blender Bridge v1.4.3.33

内容：
- rokoko_retarget_bridge/：Blender 插件目录。模块名保留为 rokoko_retarget_bridge，方便覆盖安装旧版。
- kimodo_patch/kimodo/demo/bridge_api.py：Kimodo 本地桥接 API 补丁，bridge_version 为 straight-style-path-toggle-v13。
- kimodo_patch/kimodo/demo/embedding_cache.py：Kimodo 侧所需的缓存辅助文件。

安装：
1. Blender 安装插件 zip：kimodo_motion_bridge_v1_4_3_33_prefs_cache.zip
2. 或者把本包里的 rokoko_retarget_bridge 文件夹复制到 Blender addons 目录。
3. 把 kimodo_patch/kimodo/demo/ 下的文件复制到你的 Kimodo 源码 kimodo/demo/ 目录，覆盖同名文件。
4. 重启 Kimodo。Blender 调试日志里看到 bridge_version = straight-style-path-toggle-v13 就是新版后端。

本版变化：
- 插件安装页面新增中文/英文界面切换。
- 插件安装页面新增“显示高级面板”开关，默认开启。
- Kimodo 高级面板新增生成缓存目录设置。
- Kimodo 高级面板新增一键删除生成缓存文件。
- “发送并显示调试源骨架”移动到 Kimodo 高级面板。
- Process Pending / Clear Pending 移动到 Kimodo 高级面板。
- 默认生成时长为 3 秒。
- Blender 会把缓存目录发给 Kimodo，过程 BVH 会保存到该目录。

注意：
- 本版没有改循环生成算法，只改 UI、偏好设置、缓存目录和打包结构。
- 删除缓存只删除指定缓存目录第一层的 .bvh/.json/.txt 文件，不递归删除文件夹。
