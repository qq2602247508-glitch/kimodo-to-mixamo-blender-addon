Kimodo to Mixamo Blender Addon - v1.4.3.28 Full Package

Contents:

1. addon/rokoko_retarget_bridge_v1_4_3_28_path_toggle.zip
   Install this zip in Blender Preferences > Add-ons > Install.

2. kimodo_patch/kimodo/demo/bridge_api.py
   Copy to:
   E:\400-game assets\ai\kimodo\kimodo-src\kimodo\demo\bridge_api.py

3. kimodo_patch/scripts/*.ps1
   Copy to:
   E:\400-game assets\ai\kimodo\scripts\

Important:

- Restart Kimodo after copying bridge_api.py.
- Kimodo health should report:
  {"ok": true, "bridge_version": "straight-style-path-toggle-v10"}

Use Path Constraint:

- ON: normal generation is constrained to move along a straight path.
- OFF: normal generation is prompt-only, better for idle, attack, dance, wave, and in-place actions.
- Loop Generate + Bind always uses path constraint because the loop workflow depends on it.
